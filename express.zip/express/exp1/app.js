const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const port = 8080;

app.use(express.json());


app.post("/details", (req, res) => {
  let data = req.body.detail;
  console.log(req.body);

  fs.appendFile("data.txt", data + "\n", (err) => {
    if (err) {
      console.log("File Unable to Write", err);
    }

    res.json({
      message: "Data Received  ",
      value: req.body.detail,
    });
  });
});


app.get("/",(req , res) =>{
      res.sendFile(path.join(__dirname,"index.html"))
})

app.get("/script.js",(req , res) =>{
      res.sendFile(path.join(__dirname,"script.js"))
})



app.get("/details", (req, res) => {
  console.log(req.query);
  fs.readFile("data.txt", "utf-8", (err,data) => {
    if (err) {
      console.log("File Unable to Write", err);
    }
    res.send(data)
  });
});





app.listen(port, () => {
  console.log(`server started at port ${port}`);
});
