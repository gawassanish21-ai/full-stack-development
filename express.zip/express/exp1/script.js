
const submit = document.getElementById("submit")
const read = document.getElementById("read")
const screen = document.getElementById("screen")
submit.addEventListener("click",async()=>{
    let input1 = document.getElementById("pok").value

    let details = {
        detail : input1
    }
   await Filewrite(details)
})

async function Filewrite(details){
    const response = await fetch("http://localhost:8080/details",{
        method : "POST",
        headers:{
            "content-Type":"application/json"
        },
        body:JSON.stringify(details)
    })
    const data = await response.text()
   console.log(data)
}

read.addEventListener("click",async()=>{
 
   await readData()
})


async function readData(details) {
    const response = await fetch("http://localhost:8080/details",{
              method : "GET",
              headers:{
                "content-Type" : "application/json"},})
     const data = await response.text()
 console.log(data)
 screen.textContent= data
}